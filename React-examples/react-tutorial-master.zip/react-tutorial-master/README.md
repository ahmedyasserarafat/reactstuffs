# React Tutorial: Building and Securing Your First App

Application repo accompanying this Auth0 article. In this article, you will learn how to build modern applications with React and Node.js.

[React Tutorial: Building and Securing Your First App](https://auth0.com/blog/react-tutorial-building-and-securing-your-first-app/)

