# Author Quiz

Example app for learning basics of React. This is the example app for [React Fundamentals](https://app.pluralsight.com/library/courses/react-fundamentals-update/table-of-contents) Pluralsight course by [Liam McLennan](https://github.com/liammclennan).