import React from 'react';

export const Hero = () =>
<div className="row">
	<div className="jumbotron col-10 offset-1">
		<h1>Author Quiz</h1>
		<p>select the book written by the author shown</p>
	</div>
</div>
