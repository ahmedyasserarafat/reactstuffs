# redux-saga-and-react-router-v4-example


[Watch the video to learn how it was made.](https://youtu.be/EifOGwAW5ZM)
