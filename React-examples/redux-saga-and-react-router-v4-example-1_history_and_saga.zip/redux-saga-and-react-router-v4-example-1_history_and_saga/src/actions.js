export const REQUEST_LOGIN = 'REQUEST_LOGIN';

export const requestLogin = payload => ({
  type: REQUEST_LOGIN,
  payload,
});
