# JWT Server

Blog post: https://hptechblogs.com/using-json-web-token-for-authentication/

## Install
```sh
npm install
```

## Start 
```sh
npm start
```

Note: It uses hard coded data so modify it for your ORM
