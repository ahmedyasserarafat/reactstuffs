# React JWT Authentication System

First install all the dependencies
```sh
npm install
```

To start the app type
```sh
npm start
```


