import React from 'react'

import './app.css'

export default function App() {
  return (
    <div
      className="page-container"
    >
      <h1>Online Toy Store</h1>
    </div>
  )
}
