import React from 'react'
import Cart from '../features/cart'

export default function CartPage(props) {
  return <div>
    <h1>Cart</h1>
    <Cart />
  </div>
}